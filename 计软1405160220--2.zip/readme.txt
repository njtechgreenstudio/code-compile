How to run?
step1. run "bison -d trans.y"  //generate 2 files: trans.tab.c and trans.tab.h
step2. "trans.tab.h" adds into lex.l's package
           run "lex lex.l"    //generate 1 files: lex.yy.c
step3. together 3 files
           run "tcc trans.tab.c"  //generate 1 files: trans.tab.exe
step4. run "trans.tab<in.txt"